# IAMSentinel — AWS IAM Policy Analyzer Dashboard

AI-powered IAM policy risk scanner with Red/Amber/Green categorization, powered by Claude.

---

## Project Structure

```
iam-sentinel-dashboard/
├── src/
│   ├── App.jsx                  # Root component with routing
│   ├── main.jsx                 # React entry point
│   ├── index.css                # Global styles (dark security theme)
│   ├── pages/
│   │   ├── Dashboard.jsx        # Account listing page
│   │   └── ScanReport.jsx       # Report page with RAG findings
│   └── data/
│       └── mockData.js          # Mock accounts + findings (replace with API)
├── index.html
├── package.json
├── vite.config.js
└── README.md
```

---

## Step 1 — Local Development Setup

### Prerequisites
- Node.js v18+ (download from https://nodejs.org)
- npm v9+

### Install and run

```bash
# Clone or unzip the project
cd iam-sentinel-dashboard

# Install dependencies
npm install

# Start development server
npm run dev
```

Open http://localhost:3000 in your browser.

---

## Step 2 — Connect to Real Backend (FastAPI)

The dashboard currently uses mock data in `src/data/mockData.js`.
To connect to your real FastAPI backend:

### 2a. Create an API service file

Create `src/services/api.js`:

```js
const BASE = "/api";   // proxied to http://localhost:8000 via vite.config.js

export const getAccounts = () =>
  fetch(`${BASE}/accounts`).then(r => r.json());

export const triggerScan = (accountId) =>
  fetch(`${BASE}/scan/${accountId}`, { method: "POST" }).then(r => r.json());

export const getReport = (scanId) =>
  fetch(`${BASE}/report/${scanId}`).then(r => r.json());
```

### 2b. Replace mock calls in App.jsx

In `App.jsx`, replace the `setTimeout` block in `handleScan` with:

```jsx
import { triggerScan, getReport } from "./services/api";

const handleScan = async (account) => {
  setScanning(account.id);
  try {
    const { scan_id } = await triggerScan(account.id);
    // Poll until done
    const poll = setInterval(async () => {
      const report = await getReport(scan_id);
      if (report.status === "complete") {
        clearInterval(poll);
        setScanResults(prev => ({ ...prev, [account.id]: report.findings }));
        setScanning(null);
        setSelectedAccount(account);
        setCurrentPage("report");
      }
    }, 2000);
  } catch (err) {
    console.error(err);
    setScanning(null);
  }
};
```

---

## Step 3 — Build for Production

```bash
npm run build
```

This creates a `dist/` folder with optimized static files.

---

## Step 4 — Deployment Options

---

### Option A: Vercel (Easiest — free, recommended for hackathon)

```bash
# Install Vercel CLI
npm install -g vercel

# Deploy from project root
vercel

# Follow prompts:
# > Set up and deploy? Y
# > Which scope? (your account)
# > Link to existing project? N
# > Project name: iam-sentinel
# > Directory: ./
# > Override build settings? N
```

Your app will be live at `https://iam-sentinel.vercel.app` within 60 seconds.

**For production deployment:**
```bash
vercel --prod
```

**Environment variables on Vercel:**
Go to vercel.com → your project → Settings → Environment Variables.
Add `VITE_API_URL` pointing to your backend.

---

### Option B: Netlify (Also free)

```bash
# Install Netlify CLI
npm install -g netlify-cli

# Build first
npm run build

# Deploy
netlify deploy --dir=dist --prod
```

Create `netlify.toml` in project root for SPA routing:
```toml
[[redirects]]
  from = "/*"
  to = "/index.html"
  status = 200
```

---

### Option C: AWS S3 + CloudFront (Production-grade)

```bash
# Build
npm run build

# Create S3 bucket
aws s3 mb s3://iam-sentinel-dashboard

# Enable static website hosting
aws s3 website s3://iam-sentinel-dashboard \
  --index-document index.html \
  --error-document index.html

# Upload dist folder
aws s3 sync dist/ s3://iam-sentinel-dashboard --delete

# Make public
aws s3api put-bucket-policy \
  --bucket iam-sentinel-dashboard \
  --policy '{
    "Version":"2012-10-17",
    "Statement":[{
      "Effect":"Allow",
      "Principal":"*",
      "Action":"s3:GetObject",
      "Resource":"arn:aws:s3:::iam-sentinel-dashboard/*"
    }]
  }'
```

Then create a CloudFront distribution pointing to the S3 bucket for HTTPS + CDN.

---

### Option D: Docker + Any VPS (DigitalOcean, EC2, etc.)

Create `Dockerfile` in project root:

```dockerfile
FROM node:18-alpine AS builder
WORKDIR /app
COPY package*.json ./
RUN npm install
COPY . .
RUN npm run build

FROM nginx:alpine
COPY --from=builder /app/dist /usr/share/nginx/html
COPY nginx.conf /etc/nginx/conf.d/default.conf
EXPOSE 80
CMD ["nginx", "-g", "daemon off;"]
```

Create `nginx.conf`:

```nginx
server {
    listen 80;
    root /usr/share/nginx/html;
    index index.html;

    location / {
        try_files $uri $uri/ /index.html;
    }

    location /api/ {
        proxy_pass http://backend:8000/;
        proxy_set_header Host $host;
    }
}
```

Build and run:

```bash
docker build -t iam-sentinel .
docker run -p 80:80 iam-sentinel
```

---

## Step 5 — Connecting Frontend + Backend Together (Docker Compose)

Create `docker-compose.yml` in your project root:

```yaml
version: "3.8"
services:
  frontend:
    build: ./iam-sentinel-dashboard
    ports:
      - "80:80"
    depends_on:
      - backend

  backend:
    build: ./iam-backend
    ports:
      - "8000:8000"
    environment:
      - ANTHROPIC_API_KEY=${ANTHROPIC_API_KEY}
      - AWS_ACCESS_KEY_ID=${AWS_ACCESS_KEY_ID}
      - AWS_SECRET_ACCESS_KEY=${AWS_SECRET_ACCESS_KEY}
```

Run everything:
```bash
docker-compose up --build
```

---

## Step 6 — Environment Variables

Create `.env` in the frontend project root:

```env
VITE_API_URL=http://localhost:8000
```

For production, set these in your deployment platform (Vercel/Netlify dashboard or as Docker env vars).

---

## Demo Tips for Hackathon

1. **Pre-load scan results** — mock data already includes 3 accounts with Red, Amber, and Green findings
2. **Account A (Production)** — has critical Red findings (wildcard + privilege escalation)
3. **Account B (Development)** — has Amber findings (service-level wildcards)
4. **Account C (Audit)** — mixed Red and Green (good for showing the score calculation)
5. Click any finding card to expand it and show the current policy + suggested fix
6. The security score ring animates based on the ratio of findings

---

## Tech Stack

| Layer | Technology |
|---|---|
| Framework | React 18 |
| Build tool | Vite 5 |
| Styling | Pure CSS with CSS variables |
| Fonts | Space Mono + DM Sans (Google Fonts) |
| State | React useState (no external lib needed) |
| Backend API | FastAPI (Python) — separate repo |
| AI Engine | Claude API (Anthropic) |
