import { useState } from "react";

const ENV_COLORS = {
  prod: { bg: "#ff3b3b22", border: "#ff3b3b55", text: "#ff6b6b" },
  dev: { bg: "#3b9fff22", border: "#3b9fff55", text: "#5eb8ff" },
  staging: { bg: "#ffab3b22", border: "#ffab3b55", text: "#ffc96b" },
  audit: { bg: "#a855f722", border: "#a855f755", text: "#c084fc" },
};

function AccountCard({ account, scanning, hasResults, onScan, onViewReport }) {
  const isScanning = scanning === account.id;
  const envStyle = ENV_COLORS[account.env] || ENV_COLORS.dev;
  const scanned = hasResults || account.status === "scanned";

  return (
    <div className="account-card" style={{ animationDelay: "0ms" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 16 }}>
        <div>
          <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 6 }}>
            <span className="env-badge" style={{ background: envStyle.bg, border: `1px solid ${envStyle.border}`, color: envStyle.text }}>
              {account.env.toUpperCase()}
            </span>
            {scanned && <span className="status-dot scanned" />}
            {!scanned && <span className="status-dot never" />}
          </div>
          <div className="account-name">{account.name}</div>
          <div className="account-id">ID: {account.id}</div>
        </div>
        <div className="region-tag">{account.region}</div>
      </div>

      <div className="account-meta">
        {account.lastScanned
          ? `Last scan: ${new Date(account.lastScanned).toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit" })}`
          : "Never scanned"}
      </div>

      <div style={{ display: "flex", gap: 10, marginTop: 20 }}>
        <button
          className={`btn-scan ${isScanning ? "scanning" : ""}`}
          onClick={() => onScan(account)}
          disabled={!!scanning}
        >
          {isScanning ? (
            <span style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <span className="spinner" /> Scanning...
            </span>
          ) : "Run Scan"}
        </button>
        {scanned && (
          <button className="btn-report" onClick={() => onViewReport(account)}>
            View Report
          </button>
        )}
      </div>
    </div>
  );
}

export default function Dashboard({ accounts, scanning, scanStatus, scanResults, onScan, onViewReport }) {
  const [filter, setFilter] = useState("all");

  const filtered = filter === "all" ? accounts : accounts.filter(a => a.env === filter);
  const totalScanned = accounts.filter(a => a.status === "scanned" || scanResults[a.id]).length;

  return (
    <div className="page">
      {/* Header */}
      <header className="header">
        <div className="header-inner">
          <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
            <div className="logo-icon">
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
                <path d="M12 2L2 7v10l10 5 10-5V7L12 2z" stroke="#00d4aa" strokeWidth="1.5" strokeLinejoin="round"/>
                <path d="M12 12l-10-5M12 12v10M12 12l10-5" stroke="#00d4aa" strokeWidth="1.5"/>
              </svg>
            </div>
            <div>
              <div className="logo-text">IAM<span>Sentinel</span></div>
              <div className="logo-sub">AWS Policy Analyzer</div>
            </div>
          </div>
          <div className="header-stats">
            <div className="stat-pill">
              <span className="stat-num">{accounts.length}</span>
              <span className="stat-label">Accounts</span>
            </div>
            <div className="stat-pill">
              <span className="stat-num">{totalScanned}</span>
              <span className="stat-label">Scanned</span>
            </div>
          </div>
        </div>
      </header>

      {/* Hero */}
      <section className="hero">
        <div className="hero-inner">
          <div className="hero-eyebrow">AI-Powered Cloud Security</div>
          <h1 className="hero-title">IAM Policy<br /><span>Risk Scanner</span></h1>
          <p className="hero-desc">
            Select any AWS account and run a deep scan. Claude AI analyzes every IAM policy,
            detects misconfigurations, privilege escalation paths, and categorizes risks into
            Red, Amber, and Green — with remediation guidance.
          </p>
        </div>
        <div className="hero-grid-bg" aria-hidden="true" />
      </section>

      {/* Filter bar */}
      <div className="filter-bar">
        <div className="filter-inner">
          <span className="filter-label">Filter by env:</span>
          {["all", "prod", "dev", "staging", "audit"].map(f => (
            <button
              key={f}
              className={`filter-btn ${filter === f ? "active" : ""}`}
              onClick={() => setFilter(f)}
            >
              {f}
            </button>
          ))}
        </div>
      </div>

      {/* Account grid */}
      <div className="accounts-grid">
        {filtered.map(account => (
          <AccountCard
            key={account.id}
            account={account}
            scanning={scanning}
            hasResults={!!scanResults[account.id]}
            onScan={onScan}
            onViewReport={onViewReport}
          />
        ))}
      </div>

      {/* Scanning overlay */}
      {scanning && (
        <div className="scan-overlay">
          <div className="scan-modal">
            <div className="scan-pulse" />
            <div className="scan-modal-title">Scanning in progress</div>
            <div className="scan-modal-sub">
              Extracting IAM policies and running AI analysis...
            </div>
            <div className="scan-steps">
              <div className="scan-step done">✓ Assumed IAM role via STS</div>
              <div className={`scan-step ${scanStatus === "Exporting IAM policies from AWS..." ? "active" : "done"}`}>
                {scanStatus === "Exporting IAM policies from AWS..." ? "⟳ Exporting IAM policies..." : "✓ Exported policy documents"}
              </div>
              <div className={`scan-step ${scanStatus === "Claude AI is analyzing policies..." ? "active" : "pending"}`}>
                {scanStatus === "Claude AI is analyzing policies..." ? "⟳ Claude AI analyzing..." : "○ Claude AI analysis"}
              </div>
              <div className="scan-step pending">○ Generating report</div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
