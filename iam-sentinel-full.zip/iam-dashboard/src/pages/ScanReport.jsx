import { useState } from "react";

const RAG = {
  RED:   { label: "Critical",  color: "#ff4444", bg: "#ff444418", border: "#ff444440", icon: "⬤" },
  AMBER: { label: "Medium",    color: "#ffaa00", bg: "#ffaa0018", border: "#ffaa0040", icon: "⬤" },
  GREEN: { label: "Safe",      color: "#00d4aa", bg: "#00d4aa18", border: "#00d4aa40", icon: "⬤" },
};

function PolicyBlock({ json }) {
  return (
    <pre className="policy-block">
      {JSON.stringify(json, null, 2)}
    </pre>
  );
}

function FindingCard({ finding, index }) {
  const [expanded, setExpanded] = useState(false);
  const rag = RAG[finding.category];

  return (
    <div
      className="finding-card"
      style={{ borderLeft: `3px solid ${rag.color}`, animationDelay: `${index * 60}ms` }}
    >
      <div
        className="finding-header"
        onClick={() => setExpanded(e => !e)}
        style={{ cursor: "pointer" }}
      >
        <div style={{ display: "flex", alignItems: "center", gap: 12, flex: 1 }}>
          <span className="rag-badge" style={{ color: rag.color, background: rag.bg, border: `1px solid ${rag.border}` }}>
            <span style={{ fontSize: 8 }}>{rag.icon}</span> {rag.label}
          </span>
          <div>
            <div className="finding-title">{finding.issue}</div>
            <div className="finding-meta">{finding.policyName} · {finding.statementId}</div>
          </div>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <span className="mitre-tag">{finding.mitre}</span>
          <span className="chevron" style={{ transform: expanded ? "rotate(180deg)" : "rotate(0deg)" }}>▾</span>
        </div>
      </div>

      {expanded && (
        <div className="finding-body">
          <div className="finding-section">
            <div className="section-label">Risk Explanation</div>
            <p className="risk-text">{finding.risk}</p>
          </div>

          <div className="finding-row">
            <div className="finding-section" style={{ flex: 1 }}>
              <div className="section-label">Current Policy</div>
              <PolicyBlock json={finding.current} />
            </div>
            {finding.fix && (
              <div className="finding-section" style={{ flex: 1 }}>
                <div className="section-label">Suggested Fix</div>
                <PolicyBlock json={finding.fix} />
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

function SummaryBar({ findings }) {
  const red   = findings.filter(f => f.category === "RED").length;
  const amber = findings.filter(f => f.category === "AMBER").length;
  const green = findings.filter(f => f.category === "GREEN").length;
  const total = findings.length;
  const score = total === 0 ? 100 : Math.round(((green * 1 + amber * 0.5) / (total)) * 100);

  return (
    <div className="summary-bar">
      <div className="summary-score">
        <div className="score-ring" style={{
          background: `conic-gradient(${score > 70 ? "#00d4aa" : score > 40 ? "#ffaa00" : "#ff4444"} ${score * 3.6}deg, #1a1a2e ${score * 3.6}deg)`
        }}>
          <div className="score-inner">
            <span className="score-num">{score}</span>
            <span className="score-label">/ 100</span>
          </div>
        </div>
        <div>
          <div className="score-title">Security Score</div>
          <div className="score-sub">{total} policies analyzed</div>
        </div>
      </div>

      <div className="summary-counts">
        <div className="count-item" style={{ color: "#ff4444" }}>
          <span className="count-num">{red}</span>
          <span className="count-label">Critical</span>
        </div>
        <div className="count-divider" />
        <div className="count-item" style={{ color: "#ffaa00" }}>
          <span className="count-num">{amber}</span>
          <span className="count-label">Medium</span>
        </div>
        <div className="count-divider" />
        <div className="count-item" style={{ color: "#00d4aa" }}>
          <span className="count-num">{green}</span>
          <span className="count-label">Safe</span>
        </div>
      </div>

      <div className="risk-bar-wrap">
        <div className="risk-bar-label">Risk Distribution</div>
        <div className="risk-bar">
          {red   > 0 && <div style={{ width: `${(red/total)*100}%`,   background: "#ff4444" }} />}
          {amber > 0 && <div style={{ width: `${(amber/total)*100}%`, background: "#ffaa00" }} />}
          {green > 0 && <div style={{ width: `${(green/total)*100}%`, background: "#00d4aa" }} />}
        </div>
        <div className="risk-bar-legend">
          <span style={{ color: "#ff4444" }}>■ Critical</span>
          <span style={{ color: "#ffaa00" }}>■ Medium</span>
          <span style={{ color: "#00d4aa" }}>■ Safe</span>
        </div>
      </div>
    </div>
  );
}

export default function ScanReport({ account, findings, onBack }) {
  const [activeTab, setActiveTab] = useState("all");

  const filtered = activeTab === "all"
    ? findings
    : findings.filter(f => f.category === activeTab);

  const counts = {
    all: findings.length,
    RED: findings.filter(f => f.category === "RED").length,
    AMBER: findings.filter(f => f.category === "AMBER").length,
    GREEN: findings.filter(f => f.category === "GREEN").length,
  };

  return (
    <div className="page">
      {/* Header */}
      <header className="header">
        <div className="header-inner">
          <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
            <div className="logo-icon">
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
                <path d="M12 2L2 7v10l10 5 10-5V7L12 2z" stroke="#00d4aa" strokeWidth="1.5" strokeLinejoin="round"/>
                <path d="M12 12l-10-5M12 12v10M12 12l10-5" stroke="#00d4aa" strokeWidth="1.5"/>
              </svg>
            </div>
            <div>
              <div className="logo-text">IAM<span>Sentinel</span></div>
              <div className="logo-sub">AWS Policy Analyzer</div>
            </div>
          </div>
          <button className="btn-back" onClick={onBack}>← Back to Accounts</button>
        </div>
      </header>

      {/* Report header */}
      <div className="report-hero">
        <div className="report-hero-inner">
          <div className="report-eyebrow">Security Report</div>
          <h2 className="report-title">{account?.name}</h2>
          <div className="report-meta">
            <span>Account ID: {account?.id}</span>
            <span className="dot">·</span>
            <span>Region: {account?.region}</span>
            <span className="dot">·</span>
            <span>Scanned: {new Date().toLocaleString("en-IN")}</span>
          </div>
        </div>
      </div>

      <div className="report-body">
        {/* Summary */}
        <SummaryBar findings={findings} />

        {/* Tabs */}
        <div className="tabs">
          {[
            { key: "all",   label: "All Findings" },
            { key: "RED",   label: "Critical",     color: "#ff4444" },
            { key: "AMBER", label: "Medium",        color: "#ffaa00" },
            { key: "GREEN", label: "Safe",           color: "#00d4aa" },
          ].map(tab => (
            <button
              key={tab.key}
              className={`tab-btn ${activeTab === tab.key ? "active" : ""}`}
              style={activeTab === tab.key && tab.color ? { borderColor: tab.color, color: tab.color } : {}}
              onClick={() => setActiveTab(tab.key)}
            >
              {tab.label}
              <span className="tab-count">{counts[tab.key]}</span>
            </button>
          ))}
        </div>

        {/* Findings */}
        <div className="findings-list">
          {filtered.length === 0 && (
            <div className="empty-state">No findings in this category.</div>
          )}
          {filtered.map((finding, i) => (
            <FindingCard key={finding.id} finding={finding} index={i} />
          ))}
        </div>

        {/* Footer note */}
        <div className="report-footer">
          <span>Powered by Claude AI · MITRE ATT&CK Cloud Framework</span>
        </div>
      </div>
    </div>
  );
}
