export const accounts = [
  { id: "123456789012", name: "Production Account", env: "prod", region: "us-east-1", lastScanned: "2025-05-05T10:22:00Z", status: "scanned" },
  { id: "234567890123", name: "Development Account", env: "dev", region: "ap-south-1", lastScanned: "2025-05-04T08:10:00Z", status: "scanned" },
  { id: "345678901234", name: "Staging Account", env: "staging", region: "eu-west-1", lastScanned: null, status: "never" },
  { id: "456789012345", name: "Security Audit Account", env: "audit", region: "us-west-2", lastScanned: "2025-05-03T14:55:00Z", status: "scanned" },
];

export const mockFindings = {
  "123456789012": [
    {
      id: "f1", policyName: "DeveloperFullAccess", statementId: "AllowAll",
      category: "RED", issue: "Wildcard action with wildcard resource",
      risk: "This allows ANY action on ANY AWS resource. An attacker with these credentials has complete control of the entire AWS account — they can create users, delete data, modify billing, and pivot to any service.",
      mitre: "TA0004 – Privilege Escalation",
      current: { Effect: "Allow", Action: "*", Resource: "*" },
      fix: { Effect: "Allow", Action: ["s3:GetObject", "s3:PutObject"], Resource: "arn:aws:s3:::dev-bucket/*" }
    },
    {
      id: "f2", policyName: "DevOpsRole", statementId: "IAMPassRole",
      category: "RED", issue: "iam:PassRole without resource restriction",
      risk: "PassRole without a resource constraint lets this principal assign any role to any service, enabling privilege escalation to roles with higher permissions including AdministratorAccess.",
      mitre: "TA0004 – Privilege Escalation",
      current: { Effect: "Allow", Action: "iam:PassRole", Resource: "*" },
      fix: { Effect: "Allow", Action: "iam:PassRole", Resource: "arn:aws:iam::123456789012:role/AllowedRoles/*" }
    },
    {
      id: "f3", policyName: "S3AdminPolicy", statementId: "S3Wildcard",
      category: "AMBER", issue: "Service-level wildcard on S3",
      risk: "s3:* grants all S3 operations including deletion and ACL modification. While scoped to a bucket, operations like s3:DeleteBucket or s3:PutBucketPolicy can cause significant damage.",
      mitre: "TA0040 – Impact",
      current: { Effect: "Allow", Action: "s3:*", Resource: "arn:aws:s3:::prod-bucket/*" },
      fix: { Effect: "Allow", Action: ["s3:GetObject", "s3:PutObject", "s3:ListBucket"], Resource: "arn:aws:s3:::prod-bucket/*" }
    },
    {
      id: "f4", policyName: "EC2ReadPolicy", statementId: "ReadOnly",
      category: "GREEN", issue: "Read-only access with scoped resource",
      risk: "Policy grants only ec2:Describe* actions. No write, modify, or delete permissions are present. Resource is appropriately scoped.",
      mitre: "N/A",
      current: { Effect: "Allow", Action: ["ec2:DescribeInstances", "ec2:DescribeVpcs"], Resource: "*" },
      fix: null
    },
  ],
  "234567890123": [
    {
      id: "f5", policyName: "DevBroadAccess", statementId: "LambdaAll",
      category: "AMBER", issue: "Lambda wildcard without MFA condition",
      risk: "lambda:* on all resources lets the principal deploy, delete, or invoke any Lambda function. Sensitive operations like InvokeFunction lack MFA enforcement.",
      mitre: "TA0002 – Execution",
      current: { Effect: "Allow", Action: "lambda:*", Resource: "*" },
      fix: { Effect: "Allow", Action: ["lambda:InvokeFunction", "lambda:GetFunction"], Resource: "arn:aws:lambda:ap-south-1:234567890123:function:dev-*", Condition: { BoolIfExists: { "aws:MultiFactorAuthPresent": "true" } } }
    },
    {
      id: "f6", policyName: "CloudWatchLogs", statementId: "LogsAccess",
      category: "GREEN", issue: "Scoped log access with conditions",
      risk: "Policy only allows log reading with proper resource scoping. No destructive actions permitted.",
      mitre: "N/A",
      current: { Effect: "Allow", Action: ["logs:GetLogEvents", "logs:DescribeLogGroups"], Resource: "arn:aws:logs:ap-south-1:234567890123:log-group:/aws/lambda/*" },
      fix: null
    },
  ],
  "456789012345": [
    {
      id: "f7", policyName: "AuditAdminPolicy", statementId: "PrivEscPath",
      category: "RED", issue: "Privilege escalation via CreatePolicyVersion",
      risk: "The combination of iam:CreatePolicyVersion and iam:SetDefaultPolicyVersion allows this principal to overwrite any managed policy with a new version that grants AdministratorAccess, effectively escalating to full admin.",
      mitre: "TA0004 – Privilege Escalation",
      current: { Effect: "Allow", Action: ["iam:CreatePolicyVersion", "iam:SetDefaultPolicyVersion"], Resource: "*" },
      fix: { Effect: "Allow", Action: ["iam:GetPolicy", "iam:ListPolicies"], Resource: "*" }
    },
    {
      id: "f8", policyName: "ReadOnlyAudit", statementId: "DescribeAll",
      category: "GREEN", issue: "Read-only audit access",
      risk: "Policy grants only describe/list/get permissions across services for audit purposes. Follows least-privilege principle.",
      mitre: "N/A",
      current: { Effect: "Allow", Action: ["ec2:Describe*", "s3:List*", "iam:Get*", "iam:List*"], Resource: "*" },
      fix: null
    },
  ],
};
