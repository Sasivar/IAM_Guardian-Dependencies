/**
 * API service — all calls to the FastAPI backend go through here.
 * The Vite proxy in vite.config.js forwards /api/* to http://localhost:8000
 */

const BASE = "/api";

// ── Accounts ──────────────────────────────────────────────────────────────────

export async function getAccounts() {
  const res = await fetch(`${BASE}/accounts/`);
  if (!res.ok) throw new Error("Failed to fetch accounts");
  return res.json();
}

// ── Scan ──────────────────────────────────────────────────────────────────────

export async function triggerScan(accountId) {
  const res = await fetch(`${BASE}/scan/${accountId}`, { method: "POST" });
  if (!res.ok) throw new Error("Failed to start scan");
  return res.json(); // { scan_id, account_id, status, message }
}

// ── Report ────────────────────────────────────────────────────────────────────

export async function getReport(scanId) {
  const res = await fetch(`${BASE}/report/${scanId}`);
  if (!res.ok) throw new Error("Failed to fetch report");
  return res.json(); // { status, findings, security_score, ... }
}

export async function getLatestReport(accountId) {
  const res = await fetch(`${BASE}/report/latest/${accountId}`);
  if (!res.ok) throw new Error("No report found for this account");
  return res.json();
}

// ── Polling helper ────────────────────────────────────────────────────────────
// Polls GET /report/{scanId} every 2s until status === "complete" or "failed"

export function pollReport(scanId, onStatusUpdate, onComplete, onError) {
  const interval = setInterval(async () => {
    try {
      const report = await getReport(scanId);
      onStatusUpdate(report.status);

      if (report.status === "complete") {
        clearInterval(interval);
        onComplete(report);
      } else if (report.status === "failed") {
        clearInterval(interval);
        onError(report.error || "Scan failed");
      }
    } catch (err) {
      clearInterval(interval);
      onError(err.message);
    }
  }, 2000);

  return () => clearInterval(interval); // returns cleanup fn
}
