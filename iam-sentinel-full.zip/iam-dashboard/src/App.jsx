import { useState, useEffect } from "react";
import Dashboard from "./pages/Dashboard";
import ScanReport from "./pages/ScanReport";
import { getAccounts, triggerScan, getLatestReport, pollReport } from "./services/api";

// Set to "false" in .env to use real backend: VITE_USE_MOCK=false
const USE_MOCK = import.meta.env.VITE_USE_MOCK !== "false";

import { accounts as mockAccounts, mockFindings } from "./data/mockData";

export default function App() {
  const [currentPage, setCurrentPage]         = useState("dashboard");
  const [selectedAccount, setSelectedAccount] = useState(null);
  const [accounts, setAccounts]               = useState([]);
  const [scanResults, setScanResults]         = useState({});
  const [scanning, setScanning]               = useState(null);
  const [scanStatus, setScanStatus]           = useState("");
  const [error, setError]                     = useState(null);

  useEffect(() => {
    if (USE_MOCK) { setAccounts(mockAccounts); return; }
    getAccounts()
      .then(setAccounts)
      .catch(() => setAccounts(mockAccounts));
  }, []);

  const handleScan = async (account) => {
    setScanning(account.id);
    setError(null);
    setScanStatus("Starting scan...");

    if (USE_MOCK) {
      setTimeout(() => {
        setScanResults(prev => ({ ...prev, [account.id]: mockFindings[account.id] || [] }));
        setScanning(null); setScanStatus("");
        setSelectedAccount(account); setCurrentPage("report");
      }, 2800);
      return;
    }

    try {
      const { scan_id } = await triggerScan(account.id);
      pollReport(
        scan_id,
        (status) => setScanStatus(
          status === "exporting_policies" ? "Exporting IAM policies from AWS..." :
          status === "analyzing"          ? "Claude AI is analyzing policies..."  : "Processing..."
        ),
        (report) => {
          setScanResults(prev => ({ ...prev, [account.id]: report.findings }));
          setScanning(null); setScanStatus("");
          setSelectedAccount({ ...account, securityScore: report.security_score });
          setCurrentPage("report");
          getAccounts().then(setAccounts).catch(() => {});
        },
        (err) => { setScanning(null); setScanStatus(""); setError(`Scan failed: ${err}`); }
      );
    } catch (err) {
      setScanning(null); setScanStatus("");
      setError(`Could not start scan: ${err.message}`);
    }
  };

  const handleViewReport = async (account) => {
    if (scanResults[account.id]) {
      setSelectedAccount(account); setCurrentPage("report"); return;
    }
    if (!USE_MOCK) {
      try {
        const report = await getLatestReport(account.id);
        setScanResults(prev => ({ ...prev, [account.id]: report.findings }));
        setSelectedAccount({ ...account, securityScore: report.security_score });
        setCurrentPage("report"); return;
      } catch (e) { /* fall through */ }
    }
    setScanResults(prev => ({ ...prev, [account.id]: mockFindings[account.id] || [] }));
    setSelectedAccount(account); setCurrentPage("report");
  };

  return (
    <div style={{ minHeight: "100vh", background: "var(--bg)" }}>
      {error && (
        <div style={{
          position: "fixed", top: 16, right: 16, zIndex: 300,
          background: "#ff444422", border: "1px solid #ff4444",
          borderRadius: 8, padding: "12px 20px",
          color: "#ff8888", fontFamily: "monospace", fontSize: 13, maxWidth: 360,
        }}>
          {error}
          <button onClick={() => setError(null)} style={{ marginLeft: 12, background: "none", border: "none", color: "#ff8888", cursor: "pointer" }}>✕</button>
        </div>
      )}
      {currentPage === "dashboard" && (
        <Dashboard accounts={accounts} scanning={scanning} scanStatus={scanStatus}
          scanResults={scanResults} onScan={handleScan} onViewReport={handleViewReport} />
      )}
      {currentPage === "report" && (
        <ScanReport account={selectedAccount}
          findings={scanResults[selectedAccount?.id] || []}
          onBack={() => setCurrentPage("dashboard")} />
      )}
    </div>
  );
}
