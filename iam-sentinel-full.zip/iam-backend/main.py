from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from routers import accounts, scan, report
import uvicorn

app = FastAPI(
    title="IAMSentinel API",
    description="AI-powered AWS IAM Policy Analyzer",
    version="1.0.0"
)

# Allow frontend (React on port 3000) to call this backend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000", "http://localhost:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(accounts.router, prefix="/accounts", tags=["Accounts"])
app.include_router(scan.router,     prefix="/scan",     tags=["Scan"])
app.include_router(report.router,   prefix="/report",   tags=["Report"])

@app.get("/health")
def health():
    return {"status": "ok", "service": "IAMSentinel"}

if __name__ == "__main__":
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
