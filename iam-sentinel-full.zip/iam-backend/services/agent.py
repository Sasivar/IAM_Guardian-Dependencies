"""
Claude AI Agent — IAM Policy Analyzer

This is the heart of the project. For each IAM policy:
1. Claude receives the policy JSON + a security-expert system prompt
2. Claude calls our 5 checker tools (check_wildcards, check_privilege_escalation, etc.)
3. We execute each tool locally and return the results back to Claude
4. Claude reasons over all findings and returns structured Red/Amber/Green output
"""

import os
import json
import uuid
import anthropic
from tools.security_checks import run_tool

# ── Claude tool definitions (what Claude sees) ───────────────────────────────

TOOLS = [
    {
        "name": "check_wildcards",
        "description": "Checks the IAM policy for wildcard actions (Action: *) or wildcard resources (Resource: *). These are the most dangerous permissions in AWS.",
        "input_schema": {
            "type": "object",
            "properties": {
                "policy_document": {
                    "type": "object",
                    "description": "The IAM policy document JSON to analyze"
                }
            },
            "required": ["policy_document"]
        }
    },
    {
        "name": "check_privilege_escalation",
        "description": "Detects dangerous IAM permission combinations that allow privilege escalation — such as iam:CreatePolicyVersion + iam:SetDefaultPolicyVersion, or iam:AttachUserPolicy.",
        "input_schema": {
            "type": "object",
            "properties": {
                "policy_document": {
                    "type": "object",
                    "description": "The IAM policy document JSON to analyze"
                }
            },
            "required": ["policy_document"]
        }
    },
    {
        "name": "check_mfa_conditions",
        "description": "Checks whether sensitive or destructive actions (like s3:DeleteBucket, iam:DeleteUser) are protected by the aws:MultiFactorAuthPresent condition.",
        "input_schema": {
            "type": "object",
            "properties": {
                "policy_document": {
                    "type": "object",
                    "description": "The IAM policy document JSON to analyze"
                }
            },
            "required": ["policy_document"]
        }
    },
    {
        "name": "check_passrole_abuse",
        "description": "Detects iam:PassRole without a scoped Resource constraint. This allows assigning any role to any AWS service, enabling privilege escalation.",
        "input_schema": {
            "type": "object",
            "properties": {
                "policy_document": {
                    "type": "object",
                    "description": "The IAM policy document JSON to analyze"
                }
            },
            "required": ["policy_document"]
        }
    },
    {
        "name": "check_resource_scope",
        "description": "Checks whether high-risk service actions (IAM, S3, EC2, KMS, etc.) are scoped to specific ARNs or broadly applied to all resources (*).",
        "input_schema": {
            "type": "object",
            "properties": {
                "policy_document": {
                    "type": "object",
                    "description": "The IAM policy document JSON to analyze"
                }
            },
            "required": ["policy_document"]
        }
    },
]

# ── System prompt ─────────────────────────────────────────────────────────────

SYSTEM_PROMPT = """You are an expert AWS cloud security engineer specializing in IAM policy analysis.

You will be given an IAM policy document. Your job is to:
1. Use ALL five checker tools on the policy document
2. Analyze the tool results carefully
3. Return a JSON array of findings

Each finding in your JSON response must follow this exact structure:
{
  "id": "<unique string like f1, f2, ...>",
  "policy_name": "<the policy name passed to you>",
  "statement_id": "<Sid from the statement, or 'UnnamedStatement'>",
  "category": "<RED | AMBER | GREEN>",
  "issue": "<short one-line description of the issue>",
  "risk": "<2-3 sentence plain-English explanation of why this is dangerous and what an attacker could do>",
  "mitre": "<MITRE ATT&CK tactic, e.g. TA0004 - Privilege Escalation, or N/A>",
  "current": <the exact statement JSON that has the issue>,
  "fix": <a corrected version of the statement JSON, or null if no fix needed>
}

Categorization rules:
- RED: wildcard Action:*, iam:PassRole on *, privilege escalation combos, any action that gives full account control
- AMBER: service-level wildcards (s3:*), Resource:* on sensitive services, missing MFA on destructive actions
- GREEN: properly scoped actions, specific ARNs, MFA conditions present, read-only permissions

IMPORTANT:
- Always use all 5 tools before forming conclusions
- If a policy has NO issues, return a single GREEN finding confirming it is safe
- Return ONLY the raw JSON array — no markdown, no explanation text, no backticks
- Be specific in the risk field — explain the real-world attack scenario
"""

# ── Agentic loop ──────────────────────────────────────────────────────────────

def analyze_policy(policy_name: str, policy_document: dict) -> list[dict]:
    """
    Runs the Claude agentic loop for a single IAM policy.
    Returns a list of finding dicts.
    """
    client = anthropic.Anthropic(api_key=os.getenv("ANTHROPIC_API_KEY"))

    messages = [
        {
            "role": "user",
            "content": f"Analyze this IAM policy named '{policy_name}':\n\n{json.dumps(policy_document, indent=2)}"
        }
    ]

    # Agentic loop — Claude calls tools, we execute them, loop until Claude is done
    while True:
        response = client.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=4096,
            system=SYSTEM_PROMPT,
            tools=TOOLS,
            messages=messages,
        )

        # Add Claude's response to the conversation
        messages.append({"role": "assistant", "content": response.content})

        # If Claude is done (no more tool calls), extract the final text
        if response.stop_reason == "end_turn":
            for block in response.content:
                if hasattr(block, "text"):
                    try:
                        return json.loads(block.text)
                    except json.JSONDecodeError:
                        # Extract JSON array if there's surrounding text
                        text = block.text
                        start = text.find("[")
                        end   = text.rfind("]") + 1
                        if start != -1 and end > start:
                            return json.loads(text[start:end])
            return []

        # If Claude wants to use tools, execute them and return results
        if response.stop_reason == "tool_use":
            tool_results = []
            for block in response.content:
                if block.type == "tool_use":
                    tool_name = block.name
                    tool_input = block.input
                    print(f"[AGENT] Claude calling tool: {tool_name}")

                    # Run the actual checker
                    result = run_tool(tool_name, tool_input.get("policy_document", {}))

                    tool_results.append({
                        "type": "tool_result",
                        "tool_use_id": block.id,
                        "content": json.dumps(result),
                    })

            # Return tool results back to Claude
            messages.append({"role": "user", "content": tool_results})

        # Safety valve
        if len(messages) > 30:
            print("[WARN] Agent loop exceeded 30 turns — breaking")
            break

    return []


# ── Main scan orchestrator ────────────────────────────────────────────────────

def run_full_scan(account_id: str, policies: list[dict]) -> list[dict]:
    """
    Runs Claude analysis on every policy in the account.
    Returns a flat list of all findings across all policies.
    """
    all_findings = []
    counter = 1

    for policy in policies:
        print(f"[SCAN] Analyzing policy: {policy['name']}")
        try:
            findings = analyze_policy(policy["name"], policy["document"])
            # Ensure each finding has a unique ID
            for f in findings:
                f["id"] = f"f{counter}"
                counter += 1
            all_findings.extend(findings)
        except Exception as e:
            print(f"[ERROR] Failed to analyze {policy['name']}: {e}")
            # Add a fallback finding so the report doesn't silently skip it
            all_findings.append({
                "id": f"f{counter}",
                "policy_name": policy["name"],
                "statement_id": "AnalysisError",
                "category": "AMBER",
                "issue": f"Analysis failed: {str(e)}",
                "risk": "Could not analyze this policy. Review it manually.",
                "mitre": "N/A",
                "current": policy["document"],
                "fix": None,
            })
            counter += 1

    return all_findings


def calculate_security_score(findings: list[dict]) -> int:
    """
    Returns a 0–100 score based on findings.
    Red findings penalize heavily, Amber moderately.
    """
    if not findings:
        return 100

    red   = sum(1 for f in findings if f.get("category") == "RED")
    amber = sum(1 for f in findings if f.get("category") == "AMBER")
    total = len(findings)

    penalty = (red * 25) + (amber * 10)
    score = max(0, 100 - penalty)
    return score
