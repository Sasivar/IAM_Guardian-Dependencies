import boto3
import json
import os
from typing import Any


def get_iam_client(role_arn: str, region: str):
    """
    Assumes the given IAM role in the target AWS account and returns
    an IAM client scoped to that account.
    """
    sts = boto3.client(
        "sts",
        aws_access_key_id=os.getenv("AWS_ACCESS_KEY_ID"),
        aws_secret_access_key=os.getenv("AWS_SECRET_ACCESS_KEY"),
        region_name=os.getenv("AWS_DEFAULT_REGION", "us-east-1"),
    )

    assumed = sts.assume_role(
        RoleArn=role_arn,
        RoleSessionName="IAMSentinelSession",
        DurationSeconds=900,
    )

    creds = assumed["Credentials"]
    return boto3.client(
        "iam",
        region_name=region,
        aws_access_key_id=creds["AccessKeyId"],
        aws_secret_access_key=creds["SecretAccessKey"],
        aws_session_token=creds["SessionToken"],
    )


def get_policy_document(iam_client, policy_arn: str) -> dict:
    """Fetches the default version document for a given policy ARN."""
    policy = iam_client.get_policy(PolicyArn=policy_arn)["Policy"]
    version_id = policy["DefaultVersionId"]
    version = iam_client.get_policy_version(
        PolicyArn=policy_arn, VersionId=version_id
    )
    return version["PolicyVersion"]["Document"]


def export_all_policies(role_arn: str, region: str) -> list[dict[str, Any]]:
    """
    Connects to the target AWS account, lists all customer-managed IAM
    policies, and returns a list of {name, arn, document} dicts.
    """
    iam = get_iam_client(role_arn, region)
    policies = []

    paginator = iam.get_paginator("list_policies")
    for page in paginator.paginate(Scope="Local"):  # Local = customer-managed only
        for policy in page["Policies"]:
            try:
                document = get_policy_document(iam, policy["Arn"])
                policies.append({
                    "name": policy["PolicyName"],
                    "arn": policy["Arn"],
                    "document": document,
                })
            except Exception as e:
                # Skip policies we can't read (e.g. broken versions)
                print(f"[WARN] Could not read {policy['PolicyName']}: {e}")

    return policies


# ── Mock fallback for local dev without real AWS credentials ──────────────────

MOCK_POLICIES = {
    "123456789012": [
        {
            "name": "DeveloperFullAccess",
            "arn": "arn:aws:iam::123456789012:policy/DeveloperFullAccess",
            "document": {
                "Version": "2012-10-17",
                "Statement": [
                    {"Effect": "Allow", "Action": "*", "Resource": "*"}
                ],
            },
        },
        {
            "name": "DevOpsRole",
            "arn": "arn:aws:iam::123456789012:policy/DevOpsRole",
            "document": {
                "Version": "2012-10-17",
                "Statement": [
                    {"Sid": "IAMPassRole", "Effect": "Allow", "Action": "iam:PassRole", "Resource": "*"},
                    {"Sid": "IAMCreatePolicy", "Effect": "Allow",
                     "Action": ["iam:CreatePolicyVersion", "iam:SetDefaultPolicyVersion"], "Resource": "*"},
                ],
            },
        },
        {
            "name": "S3AdminPolicy",
            "arn": "arn:aws:iam::123456789012:policy/S3AdminPolicy",
            "document": {
                "Version": "2012-10-17",
                "Statement": [
                    {"Effect": "Allow", "Action": "s3:*", "Resource": "arn:aws:s3:::prod-bucket/*"}
                ],
            },
        },
        {
            "name": "EC2ReadPolicy",
            "arn": "arn:aws:iam::123456789012:policy/EC2ReadPolicy",
            "document": {
                "Version": "2012-10-17",
                "Statement": [
                    {"Effect": "Allow", "Action": ["ec2:DescribeInstances", "ec2:DescribeVpcs"], "Resource": "*"}
                ],
            },
        },
    ],
    "234567890123": [
        {
            "name": "DevBroadAccess",
            "arn": "arn:aws:iam::234567890123:policy/DevBroadAccess",
            "document": {
                "Version": "2012-10-17",
                "Statement": [
                    {"Effect": "Allow", "Action": "lambda:*", "Resource": "*"}
                ],
            },
        },
        {
            "name": "CloudWatchLogs",
            "arn": "arn:aws:iam::234567890123:policy/CloudWatchLogs",
            "document": {
                "Version": "2012-10-17",
                "Statement": [
                    {
                        "Effect": "Allow",
                        "Action": ["logs:GetLogEvents", "logs:DescribeLogGroups"],
                        "Resource": "arn:aws:logs:ap-south-1:234567890123:log-group:/aws/lambda/*",
                    }
                ],
            },
        },
    ],
    "456789012345": [
        {
            "name": "AuditAdminPolicy",
            "arn": "arn:aws:iam::456789012345:policy/AuditAdminPolicy",
            "document": {
                "Version": "2012-10-17",
                "Statement": [
                    {
                        "Effect": "Allow",
                        "Action": ["iam:CreatePolicyVersion", "iam:SetDefaultPolicyVersion"],
                        "Resource": "*",
                    }
                ],
            },
        },
        {
            "name": "ReadOnlyAudit",
            "arn": "arn:aws:iam::456789012345:policy/ReadOnlyAudit",
            "document": {
                "Version": "2012-10-17",
                "Statement": [
                    {
                        "Effect": "Allow",
                        "Action": ["ec2:Describe*", "s3:List*", "iam:Get*", "iam:List*"],
                        "Resource": "*",
                    }
                ],
            },
        },
    ],
}


def export_policies_for_account(account_id: str, role_arn: str, region: str) -> list[dict]:
    """
    Main entry point. Uses real AWS if credentials are present,
    falls back to mock data for local development.
    """
    use_mock = os.getenv("USE_MOCK_AWS", "true").lower() == "true"

    if use_mock:
        print(f"[INFO] Using mock AWS data for account {account_id}")
        return MOCK_POLICIES.get(account_id, [])

    print(f"[INFO] Fetching real IAM policies for account {account_id}")
    return export_all_policies(role_arn, region)
