from models.schemas import Account
from datetime import datetime

# ── Registered AWS accounts ──────────────────────────────────────────────────
# Replace role_arn values with the actual IAM role ARNs you create in each account.
# See README for how to set these up.

ACCOUNTS: dict[str, Account] = {
    "123456789012": Account(
        id="123456789012",
        name="Production Account",
        env="prod",
        region="us-east-1",
        role_arn="arn:aws:iam::123456789012:role/IAMSentinelRole",
        last_scanned=datetime(2025, 5, 5, 10, 22),
        status="scanned",
    ),
    "234567890123": Account(
        id="234567890123",
        name="Development Account",
        env="dev",
        region="ap-south-1",
        role_arn="arn:aws:iam::234567890123:role/IAMSentinelRole",
        last_scanned=datetime(2025, 5, 4, 8, 10),
        status="scanned",
    ),
    "345678901234": Account(
        id="345678901234",
        name="Staging Account",
        env="staging",
        region="eu-west-1",
        role_arn="arn:aws:iam::345678901234:role/IAMSentinelRole",
        last_scanned=None,
        status="never",
    ),
    "456789012345": Account(
        id="456789012345",
        name="Security Audit Account",
        env="audit",
        region="us-west-2",
        role_arn="arn:aws:iam::456789012345:role/IAMSentinelRole",
        last_scanned=datetime(2025, 5, 3, 14, 55),
        status="scanned",
    ),
}

# ── In-memory scan results store ─────────────────────────────────────────────
# scan_id -> Report dict
SCAN_RESULTS: dict[str, dict] = {}
