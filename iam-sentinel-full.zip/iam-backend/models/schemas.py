from pydantic import BaseModel
from typing import Optional, Any
from datetime import datetime


class Account(BaseModel):
    id: str
    name: str
    env: str                     # prod | dev | staging | audit
    region: str
    role_arn: str                # ARN of the IAM role to assume in that account
    last_scanned: Optional[datetime] = None
    status: str = "never"        # never | scanned


class ScanRequest(BaseModel):
    account_id: str


class ScanResponse(BaseModel):
    scan_id: str
    account_id: str
    status: str                  # pending | running | complete | failed
    message: str


class Finding(BaseModel):
    id: str
    policy_name: str
    statement_id: str
    category: str                # RED | AMBER | GREEN
    issue: str
    risk: str
    mitre: str
    current: dict[str, Any]
    fix: Optional[dict[str, Any]] = None


class Report(BaseModel):
    scan_id: str
    account_id: str
    account_name: str
    status: str
    scanned_at: datetime
    findings: list[Finding]
    total_policies: int
    security_score: int
