"""
Security checker tools used by the Claude agent.
Each function takes an IAM policy document (dict) and returns a list of raw findings.
Claude calls these as tools, then reasons over the results to produce the final report.
"""

from typing import Any


# ── Dangerous permission combinations that enable privilege escalation ────────
# Source: Rhino Security Labs AWS IAM Privilege Escalation research
PRIVESC_COMBOS = [
    {
        "actions": {"iam:createpolicyversion", "iam:setdefaultpolicyversion"},
        "description": "Can overwrite any managed policy with a version granting AdministratorAccess",
    },
    {
        "actions": {"iam:createaccesskey"},
        "description": "Can create access keys for other IAM users including admins",
    },
    {
        "actions": {"iam:createloginprofile"},
        "description": "Can set a console password for any IAM user",
    },
    {
        "actions": {"iam:attachuserpolicy"},
        "description": "Can attach AdministratorAccess policy to any user including self",
    },
    {
        "actions": {"iam:attachrolepolicy"},
        "description": "Can attach AdministratorAccess policy to any role",
    },
    {
        "actions": {"iam:putuserpolicy"},
        "description": "Can inject an inline policy with full admin rights on any user",
    },
    {
        "actions": {"iam:addusertogroupaction", "iam:attachgrouppolicy"},
        "description": "Can add self to a group and attach an admin policy to that group",
    },
    {
        "actions": {"sts:assumerole"},
        "description": "Can assume roles — check if any target roles have higher privileges",
    },
]

# Services where wildcard actions are especially dangerous
HIGH_RISK_SERVICES = {
    "iam", "sts", "ec2", "s3", "lambda", "kms", "secretsmanager",
    "ssm", "cloudformation", "organizations", "billing",
}


def _normalize_actions(actions: Any) -> list[str]:
    """Normalise Action field to a lowercase list."""
    if isinstance(actions, str):
        return [actions.lower()]
    if isinstance(actions, list):
        return [a.lower() for a in actions]
    return []


def _normalize_resources(resources: Any) -> list[str]:
    if isinstance(resources, str):
        return [resources]
    if isinstance(resources, list):
        return resources
    return []


# ── Tool 1: Wildcard checker ──────────────────────────────────────────────────

def check_wildcards(policy_document: dict) -> list[dict]:
    """
    Detects Action: * or Resource: * in any Allow statement.
    Returns a list of findings.
    """
    findings = []
    for stmt in policy_document.get("Statement", []):
        if stmt.get("Effect") != "Allow":
            continue

        actions   = _normalize_actions(stmt.get("Action", []))
        resources = _normalize_resources(stmt.get("Resource", []))
        sid       = stmt.get("Sid", "UnnamedStatement")

        if "*" in actions:
            findings.append({
                "type": "WILDCARD_ACTION",
                "severity": "RED",
                "sid": sid,
                "detail": "Action: * grants every AWS action across all services.",
                "current": stmt,
            })
        elif any(a.endswith(":*") for a in actions):
            service = [a.split(":")[0] for a in actions if a.endswith(":*")]
            severity = "RED" if any(s in HIGH_RISK_SERVICES for s in service) else "AMBER"
            findings.append({
                "type": "SERVICE_WILDCARD",
                "severity": severity,
                "sid": sid,
                "detail": f"Service-level wildcard detected: {', '.join(set(service))}:*",
                "current": stmt,
            })

        if "*" in resources and "*" not in actions:
            findings.append({
                "type": "WILDCARD_RESOURCE",
                "severity": "AMBER",
                "sid": sid,
                "detail": "Resource: * means actions apply to all resources of that type in the account.",
                "current": stmt,
            })

    return findings


# ── Tool 2: Privilege escalation checker ─────────────────────────────────────

def check_privilege_escalation(policy_document: dict) -> list[dict]:
    """
    Checks for dangerous IAM permission combinations that allow privilege escalation.
    """
    findings = []
    all_actions: set[str] = set()

    for stmt in policy_document.get("Statement", []):
        if stmt.get("Effect") != "Allow":
            continue
        all_actions.update(_normalize_actions(stmt.get("Action", [])))

    for combo in PRIVESC_COMBOS:
        required = combo["actions"]
        # Match if: all required actions present, OR a wildcard covers them
        if required.issubset(all_actions) or "*" in all_actions:
            # Avoid double-reporting when wildcard already caught by check_wildcards
            if "*" in all_actions and len(required) == 1 and "sts:assumerole" not in required:
                continue
            findings.append({
                "type": "PRIVILEGE_ESCALATION",
                "severity": "RED",
                "detail": combo["description"],
                "matched_actions": list(required),
            })

    return findings


# ── Tool 3: MFA condition checker ─────────────────────────────────────────────

SENSITIVE_ACTIONS = {
    "iam:deleteuser", "iam:deletepolicy", "iam:detachuserpolicy",
    "s3:deleteobject", "s3:deletebucket", "ec2:terminateinstances",
    "kms:schedulekeydeleted", "secretsmanager:deletesecret",
    "organizations:deleteaccount",
}


def check_mfa_conditions(policy_document: dict) -> list[dict]:
    """
    Checks whether sensitive actions are protected by aws:MultiFactorAuthPresent condition.
    """
    findings = []
    for stmt in policy_document.get("Statement", []):
        if stmt.get("Effect") != "Allow":
            continue

        actions    = set(_normalize_actions(stmt.get("Action", [])))
        conditions = stmt.get("Condition", {})
        has_mfa    = (
            conditions.get("Bool", {}).get("aws:MultiFactorAuthPresent") == "true"
            or conditions.get("BoolIfExists", {}).get("aws:MultiFactorAuthPresent") == "true"
        )

        if not has_mfa:
            risky = actions & SENSITIVE_ACTIONS
            if risky or "*" in actions:
                findings.append({
                    "type": "NO_MFA_CONDITION",
                    "severity": "AMBER",
                    "sid": stmt.get("Sid", "UnnamedStatement"),
                    "detail": "Sensitive actions are not protected by aws:MultiFactorAuthPresent condition.",
                    "affected_actions": list(risky) if risky else ["*"],
                    "current": stmt,
                })

    return findings


# ── Tool 4: PassRole abuse checker ────────────────────────────────────────────

def check_passrole_abuse(policy_document: dict) -> list[dict]:
    """
    Detects iam:PassRole without a scoped Resource constraint.
    """
    findings = []
    for stmt in policy_document.get("Statement", []):
        if stmt.get("Effect") != "Allow":
            continue

        actions   = _normalize_actions(stmt.get("Action", []))
        resources = _normalize_resources(stmt.get("Resource", []))

        has_passrole    = "iam:passrole" in actions or "*" in actions
        has_wildcard_res = "*" in resources

        if has_passrole and has_wildcard_res:
            findings.append({
                "type": "PASSROLE_ABUSE",
                "severity": "RED",
                "sid": stmt.get("Sid", "UnnamedStatement"),
                "detail": "iam:PassRole with Resource: * allows assigning any role to any service, enabling privilege escalation.",
                "current": stmt,
            })

    return findings


# ── Tool 5: Resource scope checker ───────────────────────────────────────────

def check_resource_scope(policy_document: dict) -> list[dict]:
    """
    Checks whether high-risk service actions are scoped to specific ARNs.
    """
    findings = []
    for stmt in policy_document.get("Statement", []):
        if stmt.get("Effect") != "Allow":
            continue

        actions   = _normalize_actions(stmt.get("Action", []))
        resources = _normalize_resources(stmt.get("Resource", []))

        if "*" not in resources:
            continue  # Already scoped — no issue

        risky_services = {
            a.split(":")[0] for a in actions
            if ":" in a and a.split(":")[0] in HIGH_RISK_SERVICES
        }

        for svc in risky_services:
            findings.append({
                "type": "BROAD_RESOURCE_SCOPE",
                "severity": "AMBER",
                "sid": stmt.get("Sid", "UnnamedStatement"),
                "detail": f"{svc} actions apply to all resources (*). Scope to specific ARNs.",
                "service": svc,
                "current": stmt,
            })

    return findings


# ── Dispatcher: maps tool name → function ─────────────────────────────────────

TOOL_REGISTRY = {
    "check_wildcards":           check_wildcards,
    "check_privilege_escalation": check_privilege_escalation,
    "check_mfa_conditions":      check_mfa_conditions,
    "check_passrole_abuse":      check_passrole_abuse,
    "check_resource_scope":      check_resource_scope,
}


def run_tool(tool_name: str, policy_document: dict) -> list[dict]:
    """Called by the agent to execute a specific checker tool."""
    fn = TOOL_REGISTRY.get(tool_name)
    if not fn:
        return [{"error": f"Unknown tool: {tool_name}"}]
    return fn(policy_document)
