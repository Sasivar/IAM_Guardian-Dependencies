from fastapi import APIRouter, HTTPException
from models.store import SCAN_RESULTS, ACCOUNTS

router = APIRouter()


@router.get("/{scan_id}")
def get_report(scan_id: str):
    """
    Returns the scan report for a given scan_id.
    Status will be: pending | exporting_policies | analyzing | complete | failed

    The frontend polls this endpoint every 2 seconds until status == 'complete'.
    """
    result = SCAN_RESULTS.get(scan_id)
    if not result:
        raise HTTPException(status_code=404, detail=f"Scan {scan_id} not found")
    return result


@router.get("/latest/{account_id}")
def get_latest_report(account_id: str):
    """
    Returns the most recent completed scan for an account.
    Useful for the 'View Report' button on accounts that were already scanned.
    """
    if account_id not in ACCOUNTS:
        raise HTTPException(status_code=404, detail=f"Account {account_id} not found")

    # Find the latest completed scan for this account
    matching = [
        r for r in SCAN_RESULTS.values()
        if r.get("account_id") == account_id and r.get("status") == "complete"
    ]

    if not matching:
        raise HTTPException(
            status_code=404,
            detail=f"No completed scans found for account {account_id}"
        )

    # Return the most recent one
    latest = sorted(matching, key=lambda r: r.get("scanned_at", ""), reverse=True)[0]
    return latest
