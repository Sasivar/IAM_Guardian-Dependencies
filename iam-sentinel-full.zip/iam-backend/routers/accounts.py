from fastapi import APIRouter, HTTPException
from models.store import ACCOUNTS
from models.schemas import Account

router = APIRouter()


@router.get("/", response_model=list[Account])
def list_accounts():
    """Returns all registered AWS accounts."""
    return list(ACCOUNTS.values())


@router.get("/{account_id}", response_model=Account)
def get_account(account_id: str):
    """Returns a single account by ID."""
    account = ACCOUNTS.get(account_id)
    if not account:
        raise HTTPException(status_code=404, detail=f"Account {account_id} not found")
    return account
