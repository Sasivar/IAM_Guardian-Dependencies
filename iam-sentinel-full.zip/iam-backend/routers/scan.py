from fastapi import APIRouter, HTTPException, BackgroundTasks
from datetime import datetime, timezone
import uuid

from models.store import ACCOUNTS, SCAN_RESULTS
from models.schemas import ScanResponse
from services.iam_exporter import export_policies_for_account
from services.agent import run_full_scan, calculate_security_score

router = APIRouter()


def _do_scan(scan_id: str, account_id: str):
    """
    Background task: exports IAM policies and runs Claude analysis.
    Stores the result in SCAN_RESULTS.
    """
    account = ACCOUNTS.get(account_id)
    if not account:
        SCAN_RESULTS[scan_id]["status"] = "failed"
        SCAN_RESULTS[scan_id]["error"]  = "Account not found"
        return

    try:
        # Step 1: Pull IAM policies from AWS (or mock)
        SCAN_RESULTS[scan_id]["status"] = "exporting_policies"
        policies = export_policies_for_account(account.id, account.role_arn, account.region)
        print(f"[SCAN] Exported {len(policies)} policies for account {account_id}")

        # Step 2: Run Claude agent on every policy
        SCAN_RESULTS[scan_id]["status"] = "analyzing"
        findings = run_full_scan(account_id, policies)

        # Step 3: Calculate score and save report
        score = calculate_security_score(findings)
        SCAN_RESULTS[scan_id].update({
            "status":        "complete",
            "findings":      findings,
            "total_policies": len(policies),
            "security_score": score,
            "scanned_at":    datetime.now(timezone.utc).isoformat(),
            "account_name":  account.name,
        })

        # Update account's last_scanned timestamp
        account.last_scanned = datetime.now(timezone.utc)
        account.status = "scanned"
        print(f"[SCAN] Complete — {len(findings)} findings, score: {score}")

    except Exception as e:
        print(f"[ERROR] Scan failed for {account_id}: {e}")
        SCAN_RESULTS[scan_id]["status"] = "failed"
        SCAN_RESULTS[scan_id]["error"]  = str(e)


@router.post("/{account_id}", response_model=ScanResponse)
def trigger_scan(account_id: str, background_tasks: BackgroundTasks):
    """
    Triggers an async scan for the given account.
    Returns a scan_id immediately — poll GET /report/{scan_id} for results.
    """
    if account_id not in ACCOUNTS:
        raise HTTPException(status_code=404, detail=f"Account {account_id} not found")

    scan_id = str(uuid.uuid4())

    # Initialise the result slot
    SCAN_RESULTS[scan_id] = {
        "scan_id":    scan_id,
        "account_id": account_id,
        "status":     "pending",
        "findings":   [],
    }

    # Run scan in background so the API returns immediately
    background_tasks.add_task(_do_scan, scan_id, account_id)

    return ScanResponse(
        scan_id=scan_id,
        account_id=account_id,
        status="pending",
        message="Scan started. Poll GET /report/{scan_id} for results.",
    )
